﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TFE_JEU_ECHECS
{
    class Bishop : Piece
    {
        public Bishop(int[] position, string color) : base(position, color)
        {

        }
    }
}
