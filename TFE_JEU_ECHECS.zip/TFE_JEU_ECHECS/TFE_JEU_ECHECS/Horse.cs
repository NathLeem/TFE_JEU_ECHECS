﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TFE_JEU_ECHECS
{
    class Horse : Piece
    {
        public Horse(int[] position, string color) : base(position, color)
        {

        }
    }
}
