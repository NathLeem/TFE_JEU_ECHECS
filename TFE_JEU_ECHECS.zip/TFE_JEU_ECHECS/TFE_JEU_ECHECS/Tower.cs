﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TFE_JEU_ECHECS
{
    class Tower : Piece
    {
        public Tower(int[] position, string color) : base(position, color)
        {

        }
    }
}
