﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TFE_JEU_ECHECS
{ 
    class Queen : Piece
    {
        public Queen(int[] position, string color) : base(position, color)
        {

        }
    }
}
